package com.meem.medicinetime;



public interface BasePresenter {

    void start();
}
