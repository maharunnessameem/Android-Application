package com.meem.medicinetime.alarm;

import com.meem.medicinetime.BasePresenter;
import com.meem.medicinetime.BaseView;
import com.meem.medicinetime.data.source.History;
import com.meem.medicinetime.data.source.MedicineAlarm;



public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
